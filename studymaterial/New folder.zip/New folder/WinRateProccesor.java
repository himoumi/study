public class WinRateProcessor implements
    Database.Batchable<sObject>, Database.Stateful{
        
    	
    public Database.QueryLocator start(Database.BatchableContext bc) {
       return Database.getQueryLocator('Select PeopleSoft_Customer_ID__c from Account where CRM_Status__c = "ACTIVE" AND ' +
									   'RecordType.DeveloperName = "Approved_Account" ');
    }
	public void execute(Database.BatchableContext bc, List<Account> accountList){
		
		Map<String,Decimal> winRateMap = new Map<String,Decimal>();
		
		List<BU_Win_Rate__c>  winRateList = new List<BU_Win_Rate__c>();
        BU_Win_Rate__c winRateRec;
        
        System.debug('AccountList Size: '+accountList.size());
		Set<String> practices = new Set<String>();
		//List<Product2> practiceData
        String practiceDataQuery = 'Select Practice__c from Product2 where Product_Type__c = "Winzone" '+
                                      'AND isActive = true GROUP BY Practice__c'; 
        System.debug('Practice Data Size: '+practiceData.size());
		for (AggregateResult ar : Database.Query(practiceDataQuery))
        {
            practices.add((String)ar.get('Practice__c'));
        }
		       
        for(String practice : practices){
            for(Account acct : accountList){
              List<Opportunity_Service_Line_Item__c> megaDeals = new List<Opportunity_Service_Line_Item__c>(); 
              megaDeals = Database.query(
                    'SELECT Id FROM Opportunity_Service_Line_Item__c ' +
                    ' WHERE STAGE__C IN ("Won","Lost","Client Withdraw","Cognizant Withdraw","Duplicate","Partial Win")' +
                    ' AND Actual_Close_Date__c  = LAST_N_MONTHS:12 ' +
                    ' AND Opportunity1__r.Account.PeopleSoft_Customer_ID__c = \''+acct.PeopleSoft_Customer_ID__c+'\' '+
                    ' AND Product__r.Practice__c IN (\''+practice+'\') ' +
                    ' AND Opportunity1__r.Type != "Renewal" '+
                    ' AND Opportunity1__r.Type != " Renewal and Competitive " '+
                    ' AND Opportunity1__r.Type != " Renewal with New Project " ' +
                    ' AND Opportunity1__r.Type != " Expansion with Date Change " '+
                    ' AND Qualified__c = TRUE ' +
                    ' AND TCV_Share__c >= 500000000 AND TCV_Share__c <= 1000000000 ORDER BY TCV_Share__c DESC LIMIT 2 ');

                String megaDealIdToIgnore = '';
                If(megaDeals.size > 1)
					megaDealIdToIgnore = megaDeals[0].Id;
			
                System.debug('megaDealIdToIgnore: '+megaDealIdToIgnore);
				
				//put condition to append the last line
				String aggregateQry = 
							'SELECT SUM(TCV_Won_Less_than_15M__c), SUM(TCV_Won_greater_than_15M__c), '+
							'SUM(TCV_WonLoss_Less_than_15M__c),SUM(TCV_WonLoss_greater_than_15M__c) '+
							'FROM Opportunity_Service_Line_Item__c ' +
							'WHERE STAGE__C IN ("Won","Lost","Client Withdraw","Cognizant Withdraw","Duplicate","Partial Win") '+
							' AND Actual_Close_Date__c  = LAST_N_MONTHS:12 '+
							' AND Opportunity1__r.Account.PeopleSoft_Customer_ID__c = \''+acct.PeopleSoft_Customer_ID__c+'\' '+
							' AND Product__r.Practice__c IN (\''+practice+'\') ' +
							' AND Opportunity1__r.Type != "Renewal" '+
							' AND Opportunity1__r.Type != " Renewal and Competitive " '+
							' AND Opportunity1__r.Type != " Renewal with New Project " ' +
							' AND Opportunity1__r.Type != " Expansion with Date Change " '+
							' AND Qualified__c = TRUE AND TCV_Share__c < 1000000000 ';
							
				if(megaDealIdToIgnore != null)
                {
                    aggregateQry += 'AND Id != \''+megaDealIdToIgnore+'\'';
                }
							
				System.debug('aggregateQry ' + aggregateQry);
				
				winRateMap = this.getCalculatedWinRates(aggregateQry);
				System.debug('less Than 15M val ' + winRateMap.get('Win_Rate_Less_than_15M'));
				System.debug('greater Than 15M val ' + winRateMap.get('Win_Rate_Greater_than_15M'));
				System.debug('Blended val ' + winRateMap.get('Blended_Win_Rate'));
					
				//Map the DB fields with the values to update the table BU_Win_Rate__c
				if(!winRates.isEmpty()){
					winRateRec = new BU_Win_Rate__c();
					winRateRec.BU_Name__c   = acct.PeopleSoft_Customer_ID__c; 
					winRateRec.Dimension__c = prod.Practice__c;
					winRateRec.Category__c  = 'Account-Practice';
					winRateRec.WinRatioCategoryType__c = 'For all Opportunities excluding renewals(in Top Sheet)';
					winRateRec.Win_Rate_1_less_15M__c =   winRateMap.get('Win_Rate_Less_than_15M');
					winRateRec.Win_Rate_2_more_15M__c =   winRateMap.get('Win_Rate_Greater_than_15M');
					winRateRec.Win_Rate_3_Total__c    =   winRateMap.get('Blended_Win_Rate');
					winRateList.add(winRateRec);
				}
					
            }
        } 
		
		//insert the data in BU_Win_Rate__c
		if(winRateList != NULL && !winRateList.isEmpty()){
			insert winRateList;  
        }
		
    }
    public void finish(Database.BatchableContext bc){
        
        	AsyncApexJob job = [SELECT Id, Status, NumberOfErrors,
            JobItemsProcessed,
            TotalJobItems, CreatedBy.Email
            FROM AsyncApexJob
            WHERE Id = :bc.getJobId()];
    }
	
	//private method to calculate the rates and put in a Map
	private Map<String,Decimal> getCalculatedWinRates(String aggregateQry){
		
		Map<String,Decimal> winRates = new Map<String,Decimal>();
		Decimal Win_Rate_lesser               	       = 0;
		Decimal Win_Rate_greater                       = 0;
		Decimal Win_Rate_Greater_than_15M_Actual       = 0;
		Decimal Win_Rate_blended              		   = 0;
		Decimal Win_Rate_blended_actual                = 0;
		
        Decimal lt15value,gt15value,wonlosslt15value,wonlossgt15value;
		
		for (AggregateResult ar : Database.query(aggregateQry))  {
			System.debug('Aggregated Value: '+ar.get('expr0') + ' ' + ar.get('expr1') + ' ' + ar.get('expr2') + ' ' + ar.get('expr3')); 
			
			lt15value        = (ar.get('expr0') == NULL) ? 0 : (Decimal)ar.get('expr0');
			gt15value 		 = (ar.get('expr1') == NULL) ? 0 : (Decimal)ar.get('expr1');
			wonlosslt15value = (ar.get('expr2') == NULL) ? 0 : (Decimal)ar.get('expr2');
			wonlossgt15value = (ar.get('expr3') == NULL) ? 0 : (Decimal)ar.get('expr3');
			
			//Win Rate for Deal TCV < 15M
			if(wonlosslt15value > 0){
				Win_Rate_lesser = (lt15value/wonlosslt15value)* 100;
				System.debug('Win Rate Lesser ' + Win_Rate_lesser);
			}
			winRates.put('Win_Rate_Less_than_15M', Win_Rate_lesser.round(RoundingMode.HALF_UP));
						
			//Win Rate for Deal TCV > 15M
			if(wonlossgt15value > 0){
				System.debug('The value: ' + wonlossgt15value);
				Win_Rate_greater = (gt15value/wonlossgt15value)  ;
				Win_Rate_Greater_than_15M_Actual = Win_Rate_greater*100
				System.debug('Win Rate greater Actual' + Win_Rate_Greater_than_15M_Actual);									
			}
			
			if(Win_Rate_Greater_than_15M_Actual > 50 ){
				System.debug('Win rate in if... ' + Win_Rate_Greater_than_15M_Actual);
				winRates.put('Win_Rate_Greater_than_15M', 50);
				winRates.put('Win_Rate_Greater_than_15M_Actual',(Win_Rate_Greater_than_15M_Actual).round(RoundingMode.HALF_UP));
			}
			else{
				System.debug('Win rate in else... ' + Win_Rate_Greater_than_15M_Actual);
				winRates.put('Win_Rate_Greater_than_15M',(Win_Rate_Greater_than_15M_Actual).round(RoundingMode.HALF_UP));
				winRates.put('Win_Rate_Greater_than_15M_Actual',(Win_Rate_Greater_than_15M_Actual).round(RoundingMode.HALF_UP));
			}
						   
			//Blended WinRate
			if(Win_Rate_Greater_than_15M_Actual <= 50){
				Decimal result = ((lt15value + gt15value)/(wonlosslt15value + wonlossgt15value))*100 ;
				winRates.put('Blended_Win_Rate',(result).round(RoundingMode.HALF_UP));
				winRates.put('Blended_Win_Rate_Actual',(result).round(RoundingMode.HALF_UP));
			}
			else{
				if((wonlossgt15value - gt15value) > 0 ){
					Decimal result = ((lt15value+ wonlossgt15value - gt15value)/(wonlosslt15value+( wonlossgt15value - gt15value)*2))*100;
					winRates.put('Blended_Win_Rate',(result).round(RoundingMode.HALF_UP));
					winRates.put('Blended_Win_Rate_Actual',(result).round(RoundingMode.HALF_UP));
						
				}else if((wonlossgt15value - gt15value) = 0)
					Decimal result = ((lt15value+ gt15value/2)/(wonlosslt15value + gt15value)*100;
					winRates.put('Blended_Win_Rate',(result).round(RoundingMode.HALF_UP));
					winRates.put('Blended_Win_Rate_Actual',(result).round(RoundingMode.HALF_UP));
			}
		}
			
		return winRates;
	}
}