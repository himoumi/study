({
	doInit: function(component, event, helper) {
    },
    
    onRender: function(component, event, helper) {
        var recId = component.get("v.recordId");
        console.log("recordId in helper: "+recId);
        
        var action = component.get("c.getAccountActionDetails");
        action.setParams({
            "recId" : recId
        });
        action.setCallback(this, function(response){
            var state = response.getState();              
            if(state == 'SUCCESS') {
                component.set('v.AccountActionPlanId', response.getReturnValue());
            }
            if((component.get("v.AccountActionPlanId")) != null){
                var baseUrl = $A.get("$Label.c.CxBaseURL");
                console.log("BaseUrl: "+baseUrl);
                
                var pageReference = {
                    type: 'standard__webPage',
                    state: {nooverride:1},
                    attributes: {
                        "url": baseUrl+"actid="+component.get("v.AccountActionPlanId")
                    }
                };
                var navService = component.find("navService");
                navService.navigate(pageReference, true);
                
            }
		});
        $A.enqueueAction(action); 
    }
})