public with sharing class WinRateBatchv2 implements Database.Batchable<SObject>, Database.Stateful {

    Map<String, Map<String, List<Id>>> exclusionMap = new Map<String, Map<String, List<Id>>>();
    Set<String> practices = new Set<String>();
    String query;
    public WinRateBatchv2() {
        //fetch all >500M & <1B OSLIs and store their accounts & Practices.
        for(Opportunity_Service_Line_Item__c osliObj : [SELECT Id, 
                                        Opportunity1__r.Account.PeopleSoft_Customer_ID__c, 
                                        Product__r.Practice__c
                                        FROM Opportunity_Service_Line_Item__c 
                                        WHERE STAGE__C IN ('Won', 'Lost', 'Client Withdraw', 'Cognizant Withdraw', 'Duplicate', 'Partial Win') 
                                        AND Actual_Close_Date__c = LAST_N_MONTHS:12 
                                        AND Op8portunity1__r.Type != 'Renewal' 
                                        AND Opportunity1__r.Type != 'Renewal and Competitive'
                                        AND Opportunity1__r.Type != 'Renewal with New Project'
                                        AND Opportunity1__r.Type != 'Expansion with Date Change'
                                        AND Qualified__c = TRUE
                                        AND TCV_Share__c >= 500000000 AND TCV_Share__c <= 1000000000 ORDER BY TCV_Share__c DESC
                                        ])
        {
            if(!exclusionMap.containsKey(osliObj.Opportunity1__r.Account.PeopleSoft_Customer_ID__c))
            {
                exclusionMap.put(osliObj.Opportunity1__r.Account.PeopleSoft_Customer_ID__c, new Map<String, List<Id>>());
            }
            Map<String, List<Id>> practiceMap = exclusionMap.get(osliObj.Opportunity1__r.Account.PeopleSoft_Customer_ID__c);
            if(!practiceMap.containsKey(osliObj.Product__r.Practice__c))
            {
                practiceMap.put(osliObj.Product__r.Practice__c, new List<Id>());
            }
            practiceMap.get(osliObj.Product__r.Practice__c).add(osliObj.Id);
        }
        System.debug(exclusionMap);

        //collect all practices
        for (AggregateResult ar : [Select Practice__c 
                                    from Product2 
                                    where Product_Type__c = 'Winzone' 
                                    AND isActive = true
                                    GROUP BY Practice__c]) 
        {
            practices.add((String)ar.get('Practice__c'));
        }
        System.debug(practices);
        this.query = 'SELECT Id, PeopleSoft_Customer_ID__c ';
        this.query += 'from Account ';
        this.query += 'where RecordType.DeveloperName = \'Approved_Account\' ';
        this.query += 'and CRM_Status__c = \'Active\'';
    }

    public Database.QueryLocator start(Database.BatchableContext bc)
    {
        return Database.getQueryLocator(this.query);
        //approx 25,000 accounts
    }
    public void execute(Database.BatchableContext bc, List<Account> scope)
    {
        List<BU_Win_Rate__c>  winRateList = new List<BU_Win_Rate__c>();
        for(Account acc : scope)
        {
            for(String practice : this.practices)
            {
                Map<String,Decimal> winRates = new Map<String,Decimal>();
                //fetch id to ignore
                Id idToIgnore;
                Decimal Win_Rate_lesser = 0;
                Decimal Win_Rate_greater = 0;
                Decimal Win_Rate_blended = 0;
                Decimal Win_Rate_blended_actual = 0;
                Decimal Win_Rate_Not_Won_greaterthan15 = 0;
                Decimal Win_Rate_Won_Loss_greaterthan15_capped = 0;
                Decimal Win_Rate_Won_Loss_total = 0;
                Decimal Win_Rate_Won_total = 0;
                Decimal lt15value,gt15value,wonlosslt15value,wonlossgt15value;

                if(this.exclusionMap.containsKey(acc.PeopleSoft_Customer_ID__c) 
                    && this.exclusionMap.get(acc.PeopleSoft_Customer_ID__c).containsKey(practice)
                    && this.exclusionMap.get(acc.PeopleSoft_Customer_ID__c).get(practice).size() > 1)
                {
                    idToIgnore = this.exclusionMap.get(acc.PeopleSoft_Customer_ID__c).get(practice)[0];
                }
                String wrQuery = 'SELECT SUM(TCV_Won_Less_than_15M__c), SUM(TCV_Won_greater_than_15M__c), SUM(TCV_WonLoss_Less_than_15M__c),SUM(TCV_WonLoss_greater_than_15M__c) ';
                wrQuery += 'FROM Opportunity_Service_Line_Item__c ';
                wrQuery += 'WHERE STAGE__C IN (\'Won\', \'Lost\', \'Client Withdraw\', \'Cognizant Withdraw\', \'Duplicate\', \'Partial Win\') ';
                wrQuery += 'AND Actual_Close_Date__c = LAST_N_MONTHS:12 ';
                wrQuery += 'AND Opportunity1__r.Account.PeopleSoft_Customer_ID__c = \''+acc.PeopleSoft_Customer_ID__c+'\' ';
                wrQuery += 'AND Product__r.Practice__c = \''+practice+'\' ';
                wrQuery += 'AND Opportunity1__r.Type != \'Renewal\' ';
                wrQuery += 'AND Opportunity1__r.Type != \'Renewal and Competitive\' ';
                wrQuery += 'AND Opportunity1__r.Type != \'Renewal with New Project\' ';
                wrQuery += 'AND Opportunity1__r.Type != \'Expansion with Date Change\' ';
                wrQuery += 'AND Qualified__c = TRUE ';
                wrQuery += 'AND TCV_Share__c < 1000000000 ';
                if(idToIgnore != null)
                {
                    wrQuery += 'AND Id != \''+idToIgnore+'\'';
                }
                for (AggregateResult ar : Database.query(wrQuery))
                {
                    //proceed if atleast 1 OSLI was found
                    if(ar.get('expr0') != null || ar.get('expr1') != null || ar.get('expr2') != null || ar.get('expr3') != null)
                    {
                        lt15value = ar.get('expr0') == NULL?0:(Decimal)ar.get('expr0');
                        gt15value = ar.get('expr1') == NULL?0:(Decimal)ar.get('expr1');
                        wonlosslt15value = ar.get('expr2') == NULL?0:(Decimal)ar.get('expr2');
                        wonlossgt15value = ar.get('expr3') == NULL?0:(Decimal)ar.get('expr3');
                        //Win Rate for TCV Share < 15M
                        if(wonlosslt15value > 0){
                            Win_Rate_lesser = lt15value/wonlosslt15value;
                        }
                    
                        winRates.put('Win_Rate_Less_than_15M', (Win_Rate_lesser*100).round(RoundingMode.HALF_UP));
                    
                        //Win Rate for TCV Share > 15M
                        if(wonlossgt15value > 0){
                            Win_Rate_greater = gt15value/wonlossgt15value;
                        }
                    
                        //Capping applied when Win Rate for TCV Share > 15M exceeds 50%.
                        if((Win_Rate_greater*100) > 50){
                            winRates.put('Win_Rate_Greater_than_15M', 50);
                            winRates.put('Win_Rate_Greater_than_15M_Actual',(Win_Rate_greater*100).round(RoundingMode.HALF_UP));
                        }
                        else{
                            winRates.put('Win_Rate_Greater_than_15M',(Win_Rate_greater*100).round(RoundingMode.HALF_UP));
                            winRates.put('Win_Rate_Greater_than_15M_Actual',(Win_Rate_greater*100).round(RoundingMode.HALF_UP));
                        }
                    
                        //Blended Win Rate are calculated correspondingly if a capping is applied for "Win_Rate_Greater_than_15M".
                        if((wonlosslt15value + wonlossgt15value) > 0){
                            Win_Rate_blended_actual = ((lt15value + gt15value)/(wonlosslt15value + wonlossgt15value));
                            winRates.put('Blended_Win_Rate_Actual',(Win_Rate_blended_actual*100).round(RoundingMode.HALF_UP));
                            winRates.put('Blended_Win_Rate',(Win_Rate_blended_actual*100).round(RoundingMode.HALF_UP));
                        }
                    
                        if((wonlosslt15value + wonlossgt15value) > 0 && winRates.get('Win_Rate_Greater_than_15M_Actual') <= 50){
                            System.debug('Less than 50');
                            Win_Rate_blended = ((lt15value + gt15value)/(wonlosslt15value + wonlossgt15value));
                        }
                        else if((wonlosslt15value + wonlossgt15value) > 0 
                                && winRates.get('Win_Rate_Greater_than_15M_Actual') > 50)
                        {
                            System.debug('Capping Applied');
                            Win_Rate_Not_Won_greaterthan15         = wonlossgt15value - gt15value;
                            if(Win_Rate_Not_Won_greaterthan15 > 0){
                                Win_Rate_Won_Loss_greaterthan15_capped = Win_Rate_Not_Won_greaterthan15 * 2;  
                            }
                            else if(Win_Rate_Not_Won_greaterthan15 == 0){
                                Win_Rate_Not_Won_greaterthan15 = gt15value/2;
                                Win_Rate_Won_Loss_greaterthan15_capped = gt15value;
                            } 
                            Win_Rate_Won_Loss_total = wonlosslt15value + Win_Rate_Won_Loss_greaterthan15_capped;
                            Win_Rate_Won_total = lt15value +  Win_Rate_Not_Won_greaterthan15;
                            Win_Rate_blended = Win_Rate_Won_total / Win_Rate_Won_Loss_total;
                            
                        }
                        winRates.put('Blended_Win_Rate',(Win_Rate_blended*100).round(RoundingMode.HALF_UP));
                    }
                }
                if(!winRates.isEmpty())
                {
                    BU_Win_Rate__c winRateRec = new BU_Win_Rate__c();
                    winRateRec.BU_Name__c = acc.PeopleSoft_Customer_ID__c; 
                    winRateRec.Dimension__c = practice;
                    winRateRec.Category__c = 'Account-Practice';
                    winRateRec.WinRatioCategoryType__c = 'For all Opportunities excluding renewals(in Top Sheet)';
                    winRateRec.Date__c = System.today().year()+'-'+System.today().month();
                    winRateRec.Win_Rate_1_less_15M__c =   winRates.get('Win_Rate_Less_than_15M');
                    winRateRec.Win_Rate_2_more_15M__c =   winRates.get('Win_Rate_Greater_than_15M');
                    winRateRec.Win_Rate_3_Total__c    =   winRates.get('Blended_Win_Rate');
                    winRateList.add(winRateRec);
                }
            }
        }
        insert winRateList;
    }
    public void finish(Database.BatchableContext bc)
    {

    }
}