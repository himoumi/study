({
	getDetails : function(component) {
        console.log("recordId: "+component.get("v.recordId"));
        console.log("Record: "+JSON.stringify(component.get("v.record")));
        var planId = component.get("v.record").Account_Action_Plan_Id__c;
        console.log("AccountAcctionPlanId: "+planId);
        
        var baseUrl = $A.get("$Label.c.CxBaseURL");
        console.log("BaseUrl: "+baseUrl);
        
        var pageReference = {
            type: 'standard__webPage',
            state: {nooverride:1},
            attributes: {
                "url": baseUrl+"actid="+planId
            }
        };
        var navService = component.find("navService");
        navService.navigate(pageReference, true);
		
	}
    
    
})